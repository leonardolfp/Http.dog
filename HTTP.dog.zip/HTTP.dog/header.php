<!DOCTYPE html>
  <html lang="en">
    <head>
    	
    	<meta charset="utf-8">
    	<title>HTTP Dog</title>

	    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


	    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <script type="text/javascript" src="http://code.jquery.com/jquery-3.2.1.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

        <link rel="shortcut icon" href="icon.png">

        <link rel="stylesheet" href="style.css">

<!--         <div class="navbar-fixed">
          <nav>
            <div class="nav-wrapper #ff9800 orange">
              <img class="brand-logo center" src="dog.png">
              <a href="index.php" class="brand-logo left">HTTP Dog</a>
              <ul class="right hide-on-med-and-down">
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
              </ul>
            </div>
          </nav>
        </div> -->

  <nav class="nav-extended #ff9800 orange">
    <div class="nav-wrapper">
      <a href="#!" class="brand-logo center"><img src="hdog.png"></a>
      <ul class="right hide-on-med-and-down">
        <li><a>Um link</a></li>
        <li><a>Um segundo link</a></li>
        <li><a>Um terceiro link</a></li>
      </ul>
    </div>
    <div class="nav-content center">
      <span class="nav-title black-text"><br>HTTP Dog</span>
      <!-- <a class="btn-floating btn-large halfway-fab waves-effect waves-light teal">
        <i class="material-icons">add</i> -->
      </a>
    </div>
  </nav>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.materialboxed');
    var instances = M.Materialbox.init(elems, options);
  });

  // Or with jQuery

  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });
  </script>

    </head>
    <body>