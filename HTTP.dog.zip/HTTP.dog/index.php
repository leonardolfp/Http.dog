<?php  

	include_once 'header.php';

?>	

	<h2 class="cod">Código de status disponíveis:</h2>

<div class="row card #fff3e0 orange lighten-5">
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/dog9.jpg">
	</div>
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/dog10.jpg">
	</div>
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/dog3.jpg">
	</div>
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/883GtsbcqWIN9KmNazk2_19_490b6968011a91f8a256fabfbbc1072a_avatar.jpg">
	</div>
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/dog7.jpg">
	</div>
	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/dog5.jpg">
	</div>
<!-- 	<div class="col s12 m6 l4">
		<img class="materialboxed responsive-img card" data-caption="Descrição do erro !" width="250" src="Dogs_Deep_Web/36a483cd252f6812e2671af131958ea12f7276dc.jpg">
	</div> -->
</div>

<?php 

include_once 'footer.php';

?>
